
#include <raylib.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_LETRAS 9
#define MAX_OPTIONS 3

typedef struct {
    char nome[MAX_LETRAS + 1];
} Jogador;

int ShowMenu(void);
void ProcessInput(Jogador *jogador, int *contletra, bool *nomedeentrada);

int main()
{
    int opcao_menu = ShowMenu(); // Exibe o menu e obt�m a op��o selecionada

    if (opcao_menu == 0) // Op��o Iniciar
    {
        const int screenWidth = 800;
        const int screenHeight = 800;

        InitWindow(screenWidth, screenHeight, "SNAKE-GAME");

        Jogador jogador;
        for (int i = 0; i <= MAX_LETRAS; i++)
            jogador.nome[i] = '\0'; // Inicializa a string do jogador com null terminators

        int contletra = 0; // Contagem de letras inseridas
        bool nomedeentrada = false; // Flag para verificar se o nome foi inserido

        Rectangle textBox = {screenWidth / 2.0f - 100, 180, 225, 50}; // Desenha a caixa

        SetTargetFPS(60);

        while (!WindowShouldClose())
        {
            ProcessInput(&jogador, &contletra, &nomedeentrada); // Processa a entrada de caracteres

            BeginDrawing(); // In�cio do desenho na janela

            ClearBackground(RAYWHITE); // Limpa a tela com cor branca

            if (!nomedeentrada) // Mostra a caixa de texto somente se o nome n�o foi inserido
            {
                DrawRectangleRec(textBox, LIGHTGRAY);
                DrawRectangleLines((int)textBox.x, (int)textBox.y, (int)textBox.width, (int)textBox.height, DARKGRAY);

                DrawText(jogador.nome, (int)textBox.x + 5, (int)textBox.y + 8, 40, MAROON);

                DrawText(TextFormat("NOME DO JOGADOR: %i/%i", contletra, MAX_LETRAS), 300, 250, 20, DARKGRAY);
            }

            EndDrawing(); // Fim do desenho na janela
        }

        CloseWindow(); // Fecha a janela principal
    }
    else if (opcao_menu == 1) // Op��o Scoreboard
    {
        // FAZER AQUI: SCOREBOARD
    }
    else // Op��o Sair do jogo
    {
        printf("saiu");
    }

    return 0;
}

int ShowMenu(void)
{
    int screenWidth = 1200;
    int screenHeight = 800;

    InitWindow(screenWidth, screenHeight, "Menu Inicial");

    Texture2D background = LoadTexture("C:/Users/Acer/Downloads/snake test1.png");

    int selectedOption = 0;
    bool optionVisible = true;
    float blinkTime = 0.0f;

    SetTargetFPS(60);

    while (!WindowShouldClose())
    {
        blinkTime += GetFrameTime();

        if (blinkTime >= 0.5f)
        {
            optionVisible = !optionVisible;
            blinkTime = 0.0f;
        }

        BeginDrawing();

        ClearBackground(RAYWHITE);

        DrawTexture(background, 0, 0, WHITE);

        DrawText("MENU", screenWidth / 2 - MeasureText("MENU", 100) / 2, 150, 100, RED);

        const char *options[MAX_OPTIONS] = {"Iniciar", "Scoreboard", "Sair do Jogo"};

        for (int i = 0; i < MAX_OPTIONS; i++)
        {
            int textWidth = MeasureText(options[i], 60);
            int posX = screenWidth / 2 - textWidth / 2;
            int posY = 400 + 70 * i;

            if (i == selectedOption && optionVisible)
            {
                DrawText(options[i], posX, posY, 60, WHITE);
            }
            else
            {
                DrawText(options[i], posX, posY, 60, RED);
            }
        }

        EndDrawing();

        if (IsKeyPressed(KEY_UP))
        {
            selectedOption--;
            if (selectedOption < 0)
                selectedOption = MAX_OPTIONS - 1;
        }
        else if (IsKeyPressed(KEY_DOWN))
        {
            selectedOption++;
            if (selectedOption >= MAX_OPTIONS)
                selectedOption = 0;
        }

        if (IsKeyPressed(KEY_ENTER))
            break;
    }

    UnloadTexture(background);
    CloseWindow();

    return selectedOption;
}




void ProcessInput(Jogador *jogador, int *contletra, bool *nomedeentrada)
{
    if (IsKeyPressed(KEY_BACKSPACE))
    {
        (*contletra)--;
        if (*contletra < 0)
            *contletra = 0;
        jogador->nome[*contletra] = '\0'; // Define o null terminator para a letra apagada
    }

    int key = GetCharPressed();
    while (key > 0)
    {
        if ((key >= 32) && (key <= 125) && (*contletra < MAX_LETRAS))
        {
            jogador->nome[*contletra] = (char)key;
            (*contletra)++;
        }

        key = GetCharPressed();
    }

    if (IsKeyPressed(KEY_ENTER))
    {
        *nomedeentrada = true;
    }
}

